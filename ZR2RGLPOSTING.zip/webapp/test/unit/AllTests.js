sap.ui.define([
	"ns/com/ZR2RGLPOSTING/test/unit/controller/Main.controller"
], function () {
	"use strict";
});